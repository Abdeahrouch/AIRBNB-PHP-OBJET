-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: tp-php-airbnb
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annonces`
--

DROP TABLE IF EXISTS `annonces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonces` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `pays` varchar(150) NOT NULL,
  `ville` varchar(150) NOT NULL,
  `adresse` varchar(150) NOT NULL,
  `type_de_logement_id` int(10) NOT NULL,
  `taile` int(10) NOT NULL,
  `nbr_de_pieces` int(10) NOT NULL,
  `description` varchar(150) NOT NULL,
  `prix_par_nuit` int(10) NOT NULL,
  `nbr_de_couchages` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type_de_logement_id` (`type_de_logement_id`),
  CONSTRAINT `annonces_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `annonces_ibfk_2` FOREIGN KEY (`type_de_logement_id`) REFERENCES `type_de_logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonces`
--

LOCK TABLES `annonces` WRITE;
/*!40000 ALTER TABLE `annonces` DISABLE KEYS */;
INSERT INTO `annonces` VALUES (1,1,'Maison','Espagne','Madrid','12 Rue Nationale',4,90,3,'Grande maison situee au centre ville de Madrid',150,7),(2,1,'Chambre','France','Perpi','14 Rue Pierre',2,30,1,'Chambre grande et moderne',60,2);
/*!40000 ALTER TABLE `annonces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonces_equipement`
--

DROP TABLE IF EXISTS `annonces_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonces_equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `equipement_id` int(10) NOT NULL,
  `annonces_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `equipement_id` (`equipement_id`),
  KEY `annonces_id` (`annonces_id`),
  CONSTRAINT `annonces_equipement_ibfk_1` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`),
  CONSTRAINT `annonces_equipement_ibfk_2` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonces_equipement`
--

LOCK TABLES `annonces_equipement` WRITE;
/*!40000 ALTER TABLE `annonces_equipement` DISABLE KEYS */;
INSERT INTO `annonces_equipement` VALUES (1,2,2);
/*!40000 ALTER TABLE `annonces_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
INSERT INTO `equipement` VALUES (1,'Wi-Fi'),(2,'Télévision'),(3,'Climatisation'),(4,'Chauffage'),(5,'Cuisine équipée'),(6,'Réfrigérateur'),(7,'Machine à café'),(8,'Micro-ondes'),(9,'Lave-vaisselle'),(10,'Lave-linge'),(11,'Sèche-linge'),(12,'Fer à repasser'),(13,'Sèche-cheveux'),(14,'Serviettes'),(15,'Draps'),(16,'Parking'),(17,'Piscine'),(18,'Balcon ou terrasse'),(19,'Jardin'),(20,'Barbecue'),(21,'Cheminée'),(22,'Bureau'),(23,'Gym'),(24,'Jacuzzi'),(25,'Sauna'),(26,'Ascenseur'),(27,'Détecteur de fumée'),(28,'Détecteur de monoxyde de carbone'),(29,'Kit de premiers secours'),(30,'Animaux autorisés'),(31,'Accès handicapé'),(32,'Lit bébé'),(33,'Chaise haute'),(34,'Jouets'),(35,'Console de jeux'),(36,'Lecteur DVD');
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `annonces_id` int(10) NOT NULL,
  `image_path` varchar(150) NOT NULL,
  KEY `annonces_id` (`annonces_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (2,'chambre.jpg'),(1,'maison.jpg');
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `annonces_id` int(10) NOT NULL,
  `date_debut` int(10) NOT NULL,
  `date_fin` int(10) NOT NULL,
  `nbr_de_personne` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `annonces_id` (`annonces_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`annonces_id`) REFERENCES `annonces` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_de_logement`
--

DROP TABLE IF EXISTS `type_de_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_de_logement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_de_logement`
--

LOCK TABLES `type_de_logement` WRITE;
/*!40000 ALTER TABLE `type_de_logement` DISABLE KEYS */;
INSERT INTO `type_de_logement` VALUES (1,'Appartement'),(2,'Maison'),(4,'Chambre '),(5,'Maison '),(8,'Villa'),(16,'Château'),(18,'Igloo');
/*!40000 ALTER TABLE `type_de_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `password` varchar(150) NOT NULL,
  `is_hote` tinyint(1) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `prenom` varchar(150) NOT NULL,
  `date_inscription` int(10) NOT NULL,
  `email` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'0e160bbc55e512064a50280e7edcf24ce89102f84be499bd3e3ca1c159158a544ca941f6372df53dedfbf52cf75cec75bbec05cea480fec7a825ad85e8cdacd3',1,'Ahrouch','Abde',0,'abde@abde.com'),(3,'aafea97fcd4b4c1b638620a71c7fe8c197f96056c99fb33fbf4c7302d3dac169badeec8c6dc59b21fb2487ccdacbfefe0b23ed0a666c2abc04cd720975d324b6',1,'dg','dg',1694677482,'dgd@gmail.com'),(4,'061d37665a5e6f2afaffad78973e49c58575b3ed17f50100753bcffa98f0b00b613cf61a6d6d79887038a30b31e0d79402951bed9c06a45e301cf1f1f941123d',1,'adfsd','hjghjgh',1694677866,'df@gmail.com'),(5,'c80450438e51458425afa162b06916ec593e3af1ec298e4d67bd761e509f27ddf6fae7f658c97ad479e209126ce6d5b1649590027e2ccbd7155bbd2146ec2352',1,'adfsd','dfsf',1694677906,'sdc@gmail.com'),(6,'d14f55bf714ff0e54d7fb0811c13bc02b1615c6611634ce176592e4b6d5751eabc0de9bc971d084dc027e0dc69f4e30a52d52ce705e03ae663fe8417e2670e83',0,'test','tes',1694679171,'test@te.com'),(7,'0502e39881ae0c19bd5691f048597f2611d112c9dba78ef4d736cff8011c729e17d8502b0bd3253488c9f82a727353559c564546728b73e41da7a7edac5c74ef',0,'toto','toto',1694679551,'toto@toto.com'),(8,'0502e39881ae0c19bd5691f048597f2611d112c9dba78ef4d736cff8011c729e17d8502b0bd3253488c9f82a727353559c564546728b73e41da7a7edac5c74ef',0,'toot','toto',1694679618,'toto@t.com'),(9,'5b18b571499d22b02469200f3badb48983e892c597958c21c03fe05e6cb2e19ea7dd4891ad903b6dfed569b613ed659d14f5c2489ccfb8ab7a9346c87b42abb3',0,'toto2','toto',1694679671,'toto2@2.com'),(10,'938404f1e6b54cf6b28b203fb60b8c99316ccb76776e6136bfd0567f23625725344ec28ce886042cb29e1d1f3d452f3a9ae6f275100d7cde0733194de469f964',0,'ab','ab',1694680253,'ab@abde.com'),(11,'bf0a3ff019cad184ec04117f613731d8cc6b56cd0e14a06d8d867e34a255f7dd598052785f595b04ee05578c4f2ece23a7fb6b90f4b58d2900ab8e55c65d8f40',0,'Abdes','Abdes',1694680364,'abdessamad@test.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-14 14:43:50
